public class Core: MonoBehavior{

	public static void(){
	
	Core.Detect(col.(x, y, z));
	StartCoroutine(cc(.5));
	}
	IENumerator cc(double t){
	
	Application.FixPosition and new Vector2(p.pos.x, p.pos.y * p.sun);
	
	yield repeat(true :: false (0));
	
	}





}