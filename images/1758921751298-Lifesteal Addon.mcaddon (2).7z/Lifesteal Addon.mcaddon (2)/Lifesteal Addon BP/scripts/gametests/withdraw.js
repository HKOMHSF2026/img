import { world } from 'mojang-minecraft'

world.events.beforeChat.subscribe(data => {
    if (data.message.startsWith('!withdraw')) {
        data.cancel = true
        data.sender.runCommand(`scoreboard players remove @s ls-death ${data.message.slice(10)}`)
        data.sender.runCommand(`give @s[tag=!ls-dead] lifesteal:heart ${data.message.slice(10)}`)
        data.sender.runCommand(`playsound random.orb @s`)
        data.sender.runCommand(`tellraw @s {"rawtext":[{"text":"§bWithdrew ${data.message.slice(10)} hearts"}]}`)
    }
})