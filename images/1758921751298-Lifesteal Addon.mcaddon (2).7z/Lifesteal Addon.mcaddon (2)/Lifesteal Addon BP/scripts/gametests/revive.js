import { world } from 'mojang-minecraft'

world.events.beforeChat.subscribe(data => {
    if (data.message.startsWith('!revive')) {
        data.cancel = true
        data.sender.runCommand(`effect @a[name=${data.message.slice(8)},tag=ls-dead] saturation 1 0`)
        data.sender.runCommand(`clear @s[hasitem={item=lifesteal:heart_of_life,location=slot.weapon.mainhand}] lifesteal:heart_of_life 0 1`)
        data.sender.runCommand(`tag ${data.message.slice(8)} add ls-revive`)
        data.sender.runCommand(`title @s actionbar §bSuccessfully revived ${data.message.slice(8)}`)
        data.sender.runCommand(`tellraw @a {"rawtext": [{"text":"§b${data.message.slice(8)} was revived by ${data.sender.name}"}]}`)
        data.sender.runCommand(`title ${data.message.slice(8)} actionbar §bYou were revived by${data.sender.name}!`)
    }
})