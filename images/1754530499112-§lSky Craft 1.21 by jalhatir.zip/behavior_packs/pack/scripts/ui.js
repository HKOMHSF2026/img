import { ActionFormData, ModalFormData } from "@minecraft/server-ui";
import { system } from "@minecraft/server";
import { FormatCodes } from "./util/colorCodes";
export var Ui;
(function (Ui) {
    Ui.playersWithUiAction = new Set();
    let uiResetOperations = new Map();
    function resetUi(id) {
        if (!uiResetOperations.has(id))
            return;
        uiResetOperations.get(id)();
        uiResetOperations.delete(id);
        Ui.playersWithUiAction.delete(id);
    }
    Ui.resetUi = resetUi;
    const USE_UI_TEXT_COLOR = true;
    function showPortalTravelUi(player, sourcePortal, portals, teleportPlayer, color) {
        const id = player.id;
        // sanity check to not show multiple UIs to the same player
        // also check that atleast one portal exists otherwise the player will get a malformed data ui
        if (Ui.playersWithUiAction.has(id) || portals.length === 0)
            return;
        Ui.playersWithUiAction.add(id);
        player.playSound('sound.spark_portals.tp_ready');
        const sourcePortalIndex = portals.indexOf(sourcePortal);
        let form = new ActionFormData();
        const format = USE_UI_TEXT_COLOR ?
            FormatCodes.createWrapper(FormatCodes.colors[color] || FormatCodes.BLACK) :
            (x) => x;
        let bgColor = FormatCodes.rgbColors[color] || { red: 255, green: 255, blue: 255 };
        form = form.title(format(FormatCodes.bold({
            rawtext: [{ translate: `spark_portals.ui.travel.title.${color}` }],
        })));
        for (const portal of portals) {
            form = form.button(format(portal.name
                ? { 'text': portal.name }
                : { translate: "spark_portals.ui.travel.unnamed_portal" }));
        }
        let fadeTimeout;
        let soundTimeout = system.runInterval(() => {
            if (player.isValid()) {
                player.playSound('sound.spark_portals.tp_ready_loop');
            }
        }, 40);
        player.camera.fade({
            fadeTime: {
                "fadeInTime": 1.2,
                "holdTime": 1.2,
                "fadeOutTime": 0,
            },
            fadeColor: bgColor
        });
        let fadeInDone = new Promise((resolve) => {
            system.runTimeout(() => {
                resolve();
            }, 26);
        });
        //player.addEffect('nausea', 7 * 20, {amplifier: 2, showParticles: false});
        let uiTimeout = system.runTimeout(() => {
            fadeTimeout = system.runInterval(() => {
                if (player.isValid()) {
                    player.camera.fade({
                        fadeTime: {
                            "fadeInTime": 0,
                            "holdTime": 1.2,
                            "fadeOutTime": 0.6,
                        },
                        fadeColor: bgColor
                    });
                    //player.addEffect('nausea', 1.2 * 20, {amplifier: 2, showParticles: false});
                }
            }, 20);
        }, 24);
        form.show(player).then((result) => {
            system.clearRun(soundTimeout);
            if (fadeTimeout !== undefined)
                system.clearRun(fadeTimeout);
            system.clearRun(uiTimeout);
            Ui.playersWithUiAction.delete(id);
            uiResetOperations.delete(id);
            if (player.isValid()) {
                (async () => {
                    await fadeInDone;
                    player.camera.fade({
                        fadeTime: {
                            fadeInTime: 0,
                            holdTime: 0.2,
                            fadeOutTime: 1,
                        },
                        fadeColor: bgColor
                    });
                })();
                //player.addEffect('nausea', 1 * 20, {amplifier: 2, showParticles: false});
                if (result.canceled) {
                    player.playSound('sound.spark_portals.tp_quit');
                    return;
                }
                let isToSelf = sourcePortalIndex === result.selection;
                if (isToSelf) {
                    player.onScreenDisplay.setActionBar({ "rawtext": [{ "translate": "spark_portals.ui.travel.self" }] });
                    player.playSound('sound.spark_portals.tp_failed');
                    return;
                }
                player.playSound('sound.spark_portals.tp_successful');
                teleportPlayer(portals[result.selection]);
            }
        });
        uiResetOperations.set(id, () => {
            if (soundTimeout != undefined)
                system.clearRun(soundTimeout);
            if (fadeTimeout != undefined)
                system.clearRun(fadeTimeout);
            if (uiTimeout != undefined)
                system.clearRun(uiTimeout);
            // we can't do shit about the current fade operation :cry:
            // so we just clear all the clocks running.
        });
    }
    Ui.showPortalTravelUi = showPortalTravelUi;
    function showPortalNameUi(player, update, color) {
        const id = player.id;
        if (Ui.playersWithUiAction.has(id))
            return; // sanity check
        Ui.playersWithUiAction.add(id);
        const format = FormatCodes.createWrapper(FormatCodes.colors[color] || FormatCodes.WHITE);
        let form = new ModalFormData();
        form = form.title(FormatCodes.bold(format({ translate: `spark_portals.ui.name.title.${color}` })));
        form = form.textField({ rawtext: [{ translate: "spark_portals.ui.name.field.name.name" }] }, {
            rawtext: [
                { translate: "spark_portals.ui.name.field.name.placeholder" },
            ],
        });
        let uiTimeout = system.runTimeout(() => {
            if (player.isValid()) {
                form.show(player).then((result) => {
                    if (result.canceled) {
                    }
                    else {
                        const name = result.formValues[0].toString();
                        update(name);
                    }
                    resetUi(id);
                });
            }
            else {
                resetUi(id);
            }
        }, 20);
        uiResetOperations.set(id, () => {
            system.clearRun(uiTimeout);
        });
    }
    Ui.showPortalNameUi = showPortalNameUi;
})(Ui || (Ui = {}));
//# sourceMappingURL=ui.js.map