import { world } from "@minecraft/server";
export function getOrCreateScoreboard(id) {
    let scoreboard = world.scoreboard.getObjective(id);
    if (!scoreboard) {
        scoreboard = world.scoreboard.addObjective(id, id);
    }
    return scoreboard;
}
//# sourceMappingURL=getOrCreateScoreboard.js.map