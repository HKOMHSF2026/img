export var Vector3Util;
(function (Vector3Util) {
    function negate(v) {
        return {
            x: -v.x,
            y: -v.y,
            z: -v.z
        };
    }
    Vector3Util.negate = negate;
    function add(a, b) {
        return {
            x: a.x + b.x,
            y: a.y + b.y,
            z: a.z + b.z
        };
    }
    Vector3Util.add = add;
    function subtract(a, b) {
        return {
            x: a.x - b.x,
            y: a.y - b.y,
            z: a.z - b.z
        };
    }
    Vector3Util.subtract = subtract;
    function scale(a, b) {
        return {
            x: a.x * b,
            y: a.y * b,
            z: a.z * b
        };
    }
    Vector3Util.scale = scale;
    function floor(v) {
        return {
            x: Math.floor(v.x),
            y: Math.floor(v.y),
            z: Math.floor(v.z)
        };
    }
    Vector3Util.floor = floor;
    function length(a) {
        return Math.sqrt(lengthSquared(a));
    }
    Vector3Util.length = length;
    function lengthSquared(a) {
        return a.x * a.x + a.y * a.y + a.z * a.z;
    }
    Vector3Util.lengthSquared = lengthSquared;
    function normalized(a) {
        return scale(a, 1 / (length(a) || 1));
    }
    Vector3Util.normalized = normalized;
    function distance(a, b) {
        return Math.sqrt(this.distanceSquared(a, b));
    }
    Vector3Util.distance = distance;
    function distanceSquared(a, b) {
        const dx = a.x - b.x;
        const dy = a.y - b.y;
        const dz = a.z - b.z;
        return dx * dx + dy * dy + dz * dz;
    }
    Vector3Util.distanceSquared = distanceSquared;
    function dot(a, b) {
        return a.x * b.x + a.y * b.y + a.z * b.z;
    }
    Vector3Util.dot = dot;
    function cross(a, b) {
        const ax = a.x, ay = a.y, az = a.z;
        const bx = b.x, by = b.y, bz = b.z;
        return { x: ay * bz - az * by, y: az * bx - ax * bz, z: ax * by - ay * bx };
    }
    Vector3Util.cross = cross;
})(Vector3Util || (Vector3Util = {}));
//# sourceMappingURL=vector3.js.map