export var FormatCodes;
(function (FormatCodes) {
    FormatCodes.colors = {};
    FormatCodes.rgbColors = {};
    const color = (hex) => {
        return {
            red: parseInt(hex.slice(1, 3), 16) / 255,
            green: parseInt(hex.slice(3, 5), 16) / 255,
            blue: parseInt(hex.slice(5, 7), 16) / 255,
        };
    };
    function register(name, code, hex) {
        if (hex)
            FormatCodes.rgbColors[name] = color(hex);
        return (FormatCodes.colors[name] = `§${code}`);
    }
    FormatCodes.register = register;
    FormatCodes.createWrapper = (formatString) => (msg) => {
        if ('rawtext' in msg) {
            return {
                'rawtext': [
                    { "text": formatString },
                    ...msg.rawtext
                ]
            };
        }
        return {
            'rawtext': [
                { "text": formatString },
                ...(Array.isArray(msg) ? msg : [msg])
            ]
        };
    };
    FormatCodes.BLACK = register('black', '0', '#1C1C1D');
    FormatCodes.DARK_BLUE = register('blue', '1', '#7F9BFD');
    FormatCodes.DARK_GREEN = register('green', '2', '#67FC75');
    FormatCodes.DARK_AQUA = register('cyan', '3', '#35EDED');
    FormatCodes.DARK_RED = register('red', '4', '#FF7867');
    FormatCodes.DARK_PURPLE = register('magenta', '5', '#CF9EFF');
    FormatCodes.GOLD = register('orange', '6', '#FFCF84');
    FormatCodes.GRAY = register('light_gray', '8', '#EEF2FF'); // this is not to spec, but we can see it
    FormatCodes.DARK_GRAY = register('gray', '8', '#D7D4D8');
    FormatCodes.BLUE = register('light_blue', 'b', '#87E2FF'); // this is not to spec, but we can see it
    FormatCodes.GREEN = register('lime', 'a', '#DFFFA3');
    FormatCodes.AQUA = register('aqua', 'b', '#35EDED');
    FormatCodes.RED = register('red', 'c', '#FF7867');
    FormatCodes.LIGHT_PURPLE = register('pink', 'd', '#FFC1F7');
    FormatCodes.YELLOW = register('yellow', 'e', '#FFF8A3');
    FormatCodes.WHITE = register('white', 'f', '#FFFFFF');
    FormatCodes.MATERIAL_COPPER = register('brown', 'n', '#B4684D');
    FormatCodes.MATERIAL_GOLD = register('mat_gold', 'p', '#DEB12D');
    FormatCodes.MATERIAL_EMERALD = register('mat_emerald', 'q', '#47A036');
    FormatCodes.MATERIAL_DIAMOND = register('mat_diamond', 's', '#2CBAA8');
    FormatCodes.MATERIAL_AMETHYST = register('purple', 'u', '#9A5CC6');
    FormatCodes.OBFUSCATED = register('obfuscated', 'k');
    FormatCodes.BOLD = register('bold', 'l');
    FormatCodes.STRIKETHROUGH = register('strikethrough', 'm');
    FormatCodes.UNDERLINE = register('underline', 'n');
    FormatCodes.ITALIC = register('italic', 'o');
    FormatCodes.RESET = register('reset', 'r');
    FormatCodes.black = FormatCodes.createWrapper(FormatCodes.BLACK);
    FormatCodes.darkBlue = FormatCodes.createWrapper(FormatCodes.DARK_BLUE);
    FormatCodes.darkGreen = FormatCodes.createWrapper(FormatCodes.DARK_GREEN);
    FormatCodes.darkAqua = FormatCodes.createWrapper(FormatCodes.DARK_AQUA);
    FormatCodes.darkRed = FormatCodes.createWrapper(FormatCodes.DARK_RED);
    FormatCodes.darkPurple = FormatCodes.createWrapper(FormatCodes.DARK_PURPLE);
    FormatCodes.gold = FormatCodes.createWrapper(FormatCodes.GOLD);
    FormatCodes.gray = FormatCodes.createWrapper(FormatCodes.GRAY);
    FormatCodes.darkGray = FormatCodes.createWrapper(FormatCodes.DARK_GRAY);
    FormatCodes.blue = FormatCodes.createWrapper(FormatCodes.BLUE);
    FormatCodes.green = FormatCodes.createWrapper(FormatCodes.GREEN);
    FormatCodes.aqua = FormatCodes.createWrapper(FormatCodes.AQUA);
    FormatCodes.red = FormatCodes.createWrapper(FormatCodes.RED);
    FormatCodes.lightPurple = FormatCodes.createWrapper(FormatCodes.LIGHT_PURPLE);
    FormatCodes.yellow = FormatCodes.createWrapper(FormatCodes.YELLOW);
    FormatCodes.white = FormatCodes.createWrapper(FormatCodes.WHITE);
    FormatCodes.obfuscated = FormatCodes.createWrapper(FormatCodes.OBFUSCATED);
    FormatCodes.bold = FormatCodes.createWrapper(FormatCodes.BOLD);
    FormatCodes.strikethrough = FormatCodes.createWrapper(FormatCodes.STRIKETHROUGH);
    FormatCodes.underline = FormatCodes.createWrapper(FormatCodes.UNDERLINE);
    FormatCodes.italic = FormatCodes.createWrapper(FormatCodes.ITALIC);
    FormatCodes.reset = FormatCodes.createWrapper(FormatCodes.RESET);
    FormatCodes.colorBuilders = {
        black: FormatCodes.black,
        darkBlue: FormatCodes.darkBlue,
        darkGreen: FormatCodes.darkGreen,
        darkAqua: FormatCodes.darkAqua,
        darkRed: FormatCodes.darkRed,
        darkPurple: FormatCodes.darkPurple,
        gold: FormatCodes.gold,
        gray: FormatCodes.gray,
        darkGray: FormatCodes.darkGray,
        blue: FormatCodes.blue,
        green: FormatCodes.green,
        aqua: FormatCodes.aqua,
        red: FormatCodes.red,
        lightPurple: FormatCodes.lightPurple,
        yellow: FormatCodes.yellow,
        white: FormatCodes.white,
    };
})(FormatCodes || (FormatCodes = {}));
//# sourceMappingURL=colorCodes.js.map