import { world, system, BlockPermutation, ItemStack, Direction, GameMode } from "@minecraft/server";
import { Portal } from "./portal";
import { Guidebook } from "./guidebook";
import { Vector3Util } from "./util/vector3";
// guidebook on join
Guidebook.init({
    entityId: "spark_portals:guide_book",
    itemId: "spark_portals:guide_book_spawn_egg",
    joinString: "spark_portals.chat.is_active",
    tag: "spark_portals:has_joined_before",
});
const ignitionItems = new Set([
    "minecraft:flint_and_steel",
    "minecraft:fire_charge",
]);
world.beforeEvents.itemUseOn.subscribe((event) => {
    if (ignitionItems.has(event.itemStack.typeId)) {
        if (Portal.isPortalFrameBlock(event.block)) {
            let possiblePortals = Portal.find(event.block.dimension, event.block.location, event.blockFace);
            if (possiblePortals) {
                Portal.create(event.source, possiblePortals[0]);
            }
        }
        else {
            let offset = { x: 0, y: -1, z: 0 };
            switch (event.blockFace) {
                case Direction.North:
                    offset.z = -1;
                    break;
                case Direction.South:
                    offset.z = 1;
                    break;
                case Direction.East:
                    offset.x = 1;
                    break;
                case Direction.West:
                    offset.x = -1;
                    break;
            }
            let possiblePortals = Portal.find(event.block.dimension, Vector3Util.add(event.block.location, offset), Direction.Up);
            if (possiblePortals) {
                Portal.create(event.source, possiblePortals[0]);
            }
        }
    }
});
function tick() {
    Portal.tick();
}
world.afterEvents.playerPlaceBlock.subscribe((event) => {
    if (Portal.isLocationNearPortal(event.block.location, event.block.dimension)) {
        let res;
        try {
            res = Portal.isPortalFrameBlock(event.block);
        }
        catch (e) {
            return; // the block is likely unloaded or unaccessible.
        }
        if (res) {
            // this is a portal frame block
            Portal.rescan(event.block.location, event.dimension, true);
        }
    }
});
world.beforeEvents.playerBreakBlock.subscribe((event) => {
    if (Portal.isLocationNearPortal(event.block.location, event.block.dimension)) {
        let blockId;
        try {
            blockId = Portal.isPortalFrameBlock(event.block);
        }
        catch (e) {
            return; // the block is likely unloaded or unaccessible.
        }
        if (blockId) {
            let color = Portal.getColor(blockId);
            let block = event.block;
            if (blockId === `spark_portals:${color}_portal_frame`) {
                system.run(() => {
                    Portal.rescan(block.location, block.dimension, false);
                });
                return;
            }
            let creativePlayer = world.getPlayers({ "gameMode": GameMode.creative }).find((player) => {
                return player.id === event.player.id;
            });
            if (creativePlayer) {
                system.run(() => {
                    Portal.rescan(block.location, block.dimension, false);
                });
                return; // does not drop items in creative mode
            }
            event.cancel = true;
            system.run(() => {
                block.setPermutation(BlockPermutation.resolve("air"));
                Portal.rescan(block.location, block.dimension, false);
                block.dimension.spawnItem(new ItemStack(`spark_portals:${color}_portal_frame`, 1), Vector3Util.add(block.location, { x: 0.5, y: 0, z: 0.5 }));
            });
        }
    }
});
system.runInterval(tick, 1);
//# sourceMappingURL=main.js.map