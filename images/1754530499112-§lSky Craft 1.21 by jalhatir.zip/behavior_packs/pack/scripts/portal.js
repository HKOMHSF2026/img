import { Direction, Player, BlockPermutation, world, system, } from "@minecraft/server";
import { Vector3Util } from "./util/vector3";
import { PersistantStore } from "./store";
import { Ui } from "./ui";
import { getOrCreateScoreboard } from "./util/getOrCreateScoreboard";
import { Stats, incrementStat } from "./stats";
export var Portal;
(function (Portal) {
    Portal.portalEntityOffset = { x: 0, y: 1.5, z: 0 };
    let portalColorIds;
    (function (portalColorIds) {
        portalColorIds[portalColorIds["black"] = 0] = "black";
        portalColorIds[portalColorIds["blue"] = 1] = "blue";
        portalColorIds[portalColorIds["brown"] = 2] = "brown";
        portalColorIds[portalColorIds["cyan"] = 3] = "cyan";
        portalColorIds[portalColorIds["gray"] = 4] = "gray";
        portalColorIds[portalColorIds["green"] = 5] = "green";
        portalColorIds[portalColorIds["light_blue"] = 6] = "light_blue";
        portalColorIds[portalColorIds["light_gray"] = 7] = "light_gray";
        portalColorIds[portalColorIds["lime"] = 8] = "lime";
        portalColorIds[portalColorIds["magenta"] = 9] = "magenta";
        portalColorIds[portalColorIds["orange"] = 10] = "orange";
        portalColorIds[portalColorIds["pink"] = 11] = "pink";
        portalColorIds[portalColorIds["purple"] = 12] = "purple";
        portalColorIds[portalColorIds["red"] = 13] = "red";
        portalColorIds[portalColorIds["white"] = 14] = "white";
        portalColorIds[portalColorIds["yellow"] = 15] = "yellow";
    })(portalColorIds = Portal.portalColorIds || (Portal.portalColorIds = {}));
    let lastPlayersInPortal = new Map();
    let playersInPortal = new Map();
    const portalCooldown = getOrCreateScoreboard("spark_portals:portal_cooldown");
    Portal.portalsByColor = new Map();
    Portal.store = new PersistantStore("spark_portals:ds");
    Portal.discoveredStore = new PersistantStore("spark_portals:discovered");
    const portalBlockIds = JSON.parse('["spark_portals:black_portal_bottom_corner_x","spark_portals:black_portal_bottom_corner_x_alt","spark_portals:black_portal_bottom_corner_z","spark_portals:black_portal_bottom_corner_z_alt","spark_portals:black_portal_frame","spark_portals:black_portal_frame_column","spark_portals:black_portal_horizontal_x","spark_portals:black_portal_horizontal_z","spark_portals:black_portal_top_corner_x","spark_portals:black_portal_top_corner_x_alt","spark_portals:black_portal_top_corner_z","spark_portals:black_portal_top_corner_z_alt","spark_portals:blue_portal_bottom_corner_x","spark_portals:blue_portal_bottom_corner_x_alt","spark_portals:blue_portal_bottom_corner_z","spark_portals:blue_portal_bottom_corner_z_alt","spark_portals:blue_portal_frame","spark_portals:blue_portal_frame_column","spark_portals:blue_portal_horizontal_x","spark_portals:blue_portal_horizontal_z","spark_portals:blue_portal_top_corner_x","spark_portals:blue_portal_top_corner_x_alt","spark_portals:blue_portal_top_corner_z","spark_portals:blue_portal_top_corner_z_alt","spark_portals:brown_portal_bottom_corner_x","spark_portals:brown_portal_bottom_corner_x_alt","spark_portals:brown_portal_bottom_corner_z","spark_portals:brown_portal_bottom_corner_z_alt","spark_portals:brown_portal_frame","spark_portals:brown_portal_frame_column","spark_portals:brown_portal_horizontal_x","spark_portals:brown_portal_horizontal_z","spark_portals:brown_portal_top_corner_x","spark_portals:brown_portal_top_corner_x_alt","spark_portals:brown_portal_top_corner_z","spark_portals:brown_portal_top_corner_z_alt","spark_portals:cyan_portal_bottom_corner_x","spark_portals:cyan_portal_bottom_corner_x_alt","spark_portals:cyan_portal_bottom_corner_z","spark_portals:cyan_portal_bottom_corner_z_alt","spark_portals:cyan_portal_frame","spark_portals:cyan_portal_frame_column","spark_portals:cyan_portal_horizontal_x","spark_portals:cyan_portal_horizontal_z","spark_portals:cyan_portal_top_corner_x","spark_portals:cyan_portal_top_corner_x_alt","spark_portals:cyan_portal_top_corner_z","spark_portals:cyan_portal_top_corner_z_alt","spark_portals:gray_portal_bottom_corner_x","spark_portals:gray_portal_bottom_corner_x_alt","spark_portals:gray_portal_bottom_corner_z","spark_portals:gray_portal_bottom_corner_z_alt","spark_portals:gray_portal_frame","spark_portals:gray_portal_frame_column","spark_portals:gray_portal_horizontal_x","spark_portals:gray_portal_horizontal_z","spark_portals:gray_portal_top_corner_x","spark_portals:gray_portal_top_corner_x_alt","spark_portals:gray_portal_top_corner_z","spark_portals:gray_portal_top_corner_z_alt","spark_portals:green_portal_bottom_corner_x","spark_portals:green_portal_bottom_corner_x_alt","spark_portals:green_portal_bottom_corner_z","spark_portals:green_portal_bottom_corner_z_alt","spark_portals:green_portal_frame","spark_portals:green_portal_frame_column","spark_portals:green_portal_horizontal_x","spark_portals:green_portal_horizontal_z","spark_portals:green_portal_top_corner_x","spark_portals:green_portal_top_corner_x_alt","spark_portals:green_portal_top_corner_z","spark_portals:green_portal_top_corner_z_alt","spark_portals:light_blue_portal_bottom_corner_x","spark_portals:light_blue_portal_bottom_corner_x_alt","spark_portals:light_blue_portal_bottom_corner_z","spark_portals:light_blue_portal_bottom_corner_z_alt","spark_portals:light_blue_portal_frame","spark_portals:light_blue_portal_frame_column","spark_portals:light_blue_portal_horizontal_x","spark_portals:light_blue_portal_horizontal_z","spark_portals:light_blue_portal_top_corner_x","spark_portals:light_blue_portal_top_corner_x_alt","spark_portals:light_blue_portal_top_corner_z","spark_portals:light_blue_portal_top_corner_z_alt","spark_portals:light_gray_portal_bottom_corner_x","spark_portals:light_gray_portal_bottom_corner_x_alt","spark_portals:light_gray_portal_bottom_corner_z","spark_portals:light_gray_portal_bottom_corner_z_alt","spark_portals:light_gray_portal_frame","spark_portals:light_gray_portal_frame_column","spark_portals:light_gray_portal_horizontal_x","spark_portals:light_gray_portal_horizontal_z","spark_portals:light_gray_portal_top_corner_x","spark_portals:light_gray_portal_top_corner_x_alt","spark_portals:light_gray_portal_top_corner_z","spark_portals:light_gray_portal_top_corner_z_alt","spark_portals:lime_portal_bottom_corner_x","spark_portals:lime_portal_bottom_corner_x_alt","spark_portals:lime_portal_bottom_corner_z","spark_portals:lime_portal_bottom_corner_z_alt","spark_portals:lime_portal_frame","spark_portals:lime_portal_frame_column","spark_portals:lime_portal_horizontal_x","spark_portals:lime_portal_horizontal_z","spark_portals:lime_portal_top_corner_x","spark_portals:lime_portal_top_corner_x_alt","spark_portals:lime_portal_top_corner_z","spark_portals:lime_portal_top_corner_z_alt","spark_portals:magenta_portal_bottom_corner_x","spark_portals:magenta_portal_bottom_corner_x_alt","spark_portals:magenta_portal_bottom_corner_z","spark_portals:magenta_portal_bottom_corner_z_alt","spark_portals:magenta_portal_frame","spark_portals:magenta_portal_frame_column","spark_portals:magenta_portal_horizontal_x","spark_portals:magenta_portal_horizontal_z","spark_portals:magenta_portal_top_corner_x","spark_portals:magenta_portal_top_corner_x_alt","spark_portals:magenta_portal_top_corner_z","spark_portals:magenta_portal_top_corner_z_alt","spark_portals:orange_portal_bottom_corner_x","spark_portals:orange_portal_bottom_corner_x_alt","spark_portals:orange_portal_bottom_corner_z","spark_portals:orange_portal_bottom_corner_z_alt","spark_portals:orange_portal_frame","spark_portals:orange_portal_frame_column","spark_portals:orange_portal_horizontal_x","spark_portals:orange_portal_horizontal_z","spark_portals:orange_portal_top_corner_x","spark_portals:orange_portal_top_corner_x_alt","spark_portals:orange_portal_top_corner_z","spark_portals:orange_portal_top_corner_z_alt","spark_portals:pink_portal_bottom_corner_x","spark_portals:pink_portal_bottom_corner_x_alt","spark_portals:pink_portal_bottom_corner_z","spark_portals:pink_portal_bottom_corner_z_alt","spark_portals:pink_portal_frame","spark_portals:pink_portal_frame_column","spark_portals:pink_portal_horizontal_x","spark_portals:pink_portal_horizontal_z","spark_portals:pink_portal_top_corner_x","spark_portals:pink_portal_top_corner_x_alt","spark_portals:pink_portal_top_corner_z","spark_portals:pink_portal_top_corner_z_alt","spark_portals:purple_portal_bottom_corner_x","spark_portals:purple_portal_bottom_corner_x_alt","spark_portals:purple_portal_bottom_corner_z","spark_portals:purple_portal_bottom_corner_z_alt","spark_portals:purple_portal_frame","spark_portals:purple_portal_frame_column","spark_portals:purple_portal_horizontal_x","spark_portals:purple_portal_horizontal_z","spark_portals:purple_portal_top_corner_x","spark_portals:purple_portal_top_corner_x_alt","spark_portals:purple_portal_top_corner_z","spark_portals:purple_portal_top_corner_z_alt","spark_portals:red_portal_bottom_corner_x","spark_portals:red_portal_bottom_corner_x_alt","spark_portals:red_portal_bottom_corner_z","spark_portals:red_portal_bottom_corner_z_alt","spark_portals:red_portal_frame","spark_portals:red_portal_frame_column","spark_portals:red_portal_horizontal_x","spark_portals:red_portal_horizontal_z","spark_portals:red_portal_top_corner_x","spark_portals:red_portal_top_corner_x_alt","spark_portals:red_portal_top_corner_z","spark_portals:red_portal_top_corner_z_alt","spark_portals:white_portal_bottom_corner_x","spark_portals:white_portal_bottom_corner_x_alt","spark_portals:white_portal_bottom_corner_z","spark_portals:white_portal_bottom_corner_z_alt","spark_portals:white_portal_frame","spark_portals:white_portal_frame_column","spark_portals:white_portal_horizontal_x","spark_portals:white_portal_horizontal_z","spark_portals:white_portal_top_corner_x","spark_portals:white_portal_top_corner_x_alt","spark_portals:white_portal_top_corner_z","spark_portals:white_portal_top_corner_z_alt","spark_portals:yellow_portal_bottom_corner_x","spark_portals:yellow_portal_bottom_corner_x_alt","spark_portals:yellow_portal_bottom_corner_z","spark_portals:yellow_portal_bottom_corner_z_alt","spark_portals:yellow_portal_frame","spark_portals:yellow_portal_frame_column","spark_portals:yellow_portal_horizontal_x","spark_portals:yellow_portal_horizontal_z","spark_portals:yellow_portal_top_corner_x","spark_portals:yellow_portal_top_corner_x_alt","spark_portals:yellow_portal_top_corner_z","spark_portals:yellow_portal_top_corner_z_alt"]');
    for (const [k, v] of Portal.store.entries()) {
        const color = v.color;
        let portals = Portal.portalsByColor.get(color) || [];
        portals.push(k);
        Portal.portalsByColor.set(color, portals);
    }
    const adjacentBlockOffsets = [
        { offset: { x: 0, y: 0, z: 1 }, dir: Direction.South },
        { offset: { x: 0, y: 0, z: -1 }, dir: Direction.North },
        { offset: { x: 1, y: 0, z: 0 }, dir: Direction.East },
        { offset: { x: -1, y: 0, z: 0 }, dir: Direction.West },
    ];
    function isPortalFrameBlockPermutation(permutation) {
        return portalBlockIds.find((id) => permutation.matches(id)) || false;
    }
    Portal.isPortalFrameBlockPermutation = isPortalFrameBlockPermutation;
    function isPortalFrameBlock(block) {
        if (block.isAir)
            return false;
        return portalBlockIds.find((id) => block.permutation.matches(id));
    }
    Portal.isPortalFrameBlock = isPortalFrameBlock;
    let blockTypeMatcherCache = new Map();
    function getColor(color) {
        if (color.startsWith("spark_portals:")) {
            color = color.substring("spark_portals:".length);
            if (color.startsWith("light_")) {
                color = color.split("_").slice(0, 2).join("_");
            }
            else {
                color = color.split("_")[0];
            }
        }
        return color;
    }
    Portal.getColor = getColor;
    function createBlockTypeMatcher(color) {
        color = getColor(color);
        if (blockTypeMatcherCache.has(color)) {
            return blockTypeMatcherCache.get(color);
        }
        let blocks = [
            `spark_portals:${color}_portal_bottom_corner_x`,
            `spark_portals:${color}_portal_bottom_corner_x_alt`,
            `spark_portals:${color}_portal_bottom_corner_z`,
            `spark_portals:${color}_portal_bottom_corner_z_alt`,
            `spark_portals:${color}_portal_frame`,
            `spark_portals:${color}_portal_frame_column`,
            `spark_portals:${color}_portal_horizontal_x`,
            `spark_portals:${color}_portal_horizontal_z`,
            `spark_portals:${color}_portal_top_corner_x`,
            `spark_portals:${color}_portal_top_corner_x_alt`,
            `spark_portals:${color}_portal_top_corner_z`,
            `spark_portals:${color}_portal_top_corner_z_alt`,
        ];
        let matcher = (block) => {
            let r = blocks.some(type => block.permutation.matches(type));
            // if (!r) _debugBlock(block);
            return r;
        };
        blockTypeMatcherCache.set(color, matcher);
        return matcher;
    }
    Portal.createBlockTypeMatcher = createBlockTypeMatcher;
    function _debugBlock(block) {
        let oldPermutation = block.permutation;
        let toggle = false;
        let id = system.runInterval(() => {
            block.setPermutation(toggle ? BlockPermutation.resolve("dirt") : oldPermutation);
            toggle = !toggle;
        });
        system.runTimeout(() => {
            system.clearRun(id);
            block.setPermutation(oldPermutation);
        }, 100);
    }
    Portal.findVert = (dimension, location, side) => {
        // discover which blocks are adjacent to this block, we will use this to determine which directions we need to search for a portal structure in
        const adjacentBlocks = [];
        for (const offset of adjacentBlockOffsets) {
            const block = dimension.getBlock({
                x: location.x + offset.offset.x,
                y: location.y + side,
                z: location.z + offset.offset.z,
            });
            let color = isPortalFrameBlock(block);
            if (block.isValid() && color) {
                let c = getColor(color);
                adjacentBlocks.push({ pos: offset, color: c });
            }
        }
        const virtDirVec = {
            x: 0,
            y: side,
            z: 0,
        };
        // we have a list of direction to check for portals, now we need to check for a portal in each direction.
        // if side is 1 then we know this block is one of the bottom blocks of the portal frame
        // if side is -1 then we know this block is one of the top 2 center blocks of the portal frame
        let validPortals = [];
        find_portal: for (const edge of adjacentBlocks) {
            const offset = edge.pos;
            const borderBlock = edge.color;
            const isBorderBlock = createBlockTypeMatcher(borderBlock);
            // the position of the block that is adjacent to the current block and is not in the edge of the portal frame
            // so if this block is X we get the position of Y
            //; ?XY?
            //; #???
            const negatedOffset = Vector3Util.negate(offset.offset);
            if (!isBorderBlock(dimension.getBlock(location)))
                continue find_portal;
            let adjacentVerticalEdgeBlock = Vector3Util.add(negatedOffset, location);
            if (!isBorderBlock(dimension.getBlock(adjacentVerticalEdgeBlock)))
                continue find_portal;
            const otherEdgeOffset = Vector3Util.scale(offset.offset, -2);
            // we know the top of the portal is 2 valid blocks, now we need to check the sides of the portal
            for (let i = 1; i <= 3; i++) {
                // for each y we check the edge block in the portal frame
                // (Depicted as Z here)
                // and the middle to ensure its empty
                // (Depicted as E here)
                //; ?XY?
                //; ZEEZ
                //; ZEEZ
                //; ZEEZ
                // adjacent to the clicked block
                let edge1 = Vector3Util.add(Vector3Util.add(offset.offset, location), Vector3Util.scale(virtDirVec, i));
                if (!isBorderBlock(dimension.getBlock(edge1)))
                    continue find_portal;
                // opposite side of the portal
                let edge2 = Vector3Util.add(Vector3Util.add(otherEdgeOffset, location), Vector3Util.scale(virtDirVec, i));
                if (!isBorderBlock(dimension.getBlock(edge2)))
                    continue find_portal;
                // the column of the portal that is aligned with the clicked block
                let alignedColumn = Vector3Util.add(location, Vector3Util.scale(virtDirVec, i));
                let alignedColumnBlock = dimension.getBlock(alignedColumn);
                if (alignedColumnBlock.isValid() && !alignedColumnBlock.isAir)
                    continue find_portal;
                // the other inner column of the portal
                let nonAlignedColumn = Vector3Util.add(Vector3Util.add(negatedOffset, location), Vector3Util.scale(virtDirVec, i));
                let nonAlignedColumnBlock = dimension.getBlock(nonAlignedColumn);
                if (nonAlignedColumnBlock.isValid() && !nonAlignedColumnBlock.isAir)
                    continue find_portal;
            }
            // at this point we should have validated the following
            //; ?BB?
            //; BEEB
            //; BEEB
            //; BEEB
            //; ????
            // now we just need to check the opposite horizontal edge
            const oppositeSideOffset = Vector3Util.add(location, Vector3Util.scale(virtDirVec, 4));
            const oppisiteSideBlock = dimension.getBlock(oppositeSideOffset);
            if (!isBorderBlock(oppisiteSideBlock))
                continue find_portal;
            const finalRequiredBlock = Vector3Util.add(oppositeSideOffset, negatedOffset);
            const finalRequiredBlockBlock = dimension.getBlock(finalRequiredBlock);
            if (!isBorderBlock(finalRequiredBlockBlock))
                continue find_portal;
            // does the portal have the corner blocks to complete the frame?
            // these are optional but will effect how we render the portal
            let cornerCount = 0;
            const corner1 = Vector3Util.add(location, offset.offset);
            const corner1Block = dimension.getBlock(corner1);
            if (isBorderBlock(corner1Block))
                cornerCount++;
            const corner2 = Vector3Util.add(location, Vector3Util.scale(offset.offset, -2));
            const corner2Block = dimension.getBlock(corner2);
            if (isBorderBlock(corner2Block))
                cornerCount++;
            const corner3 = Vector3Util.add(Vector3Util.scale(virtDirVec, 4), corner2);
            const corner3Block = dimension.getBlock(corner3);
            if (isBorderBlock(corner3Block))
                cornerCount++;
            const corner4 = Vector3Util.add(Vector3Util.scale(virtDirVec, 4), corner1);
            const corner4Block = dimension.getBlock(corner4);
            if (isBorderBlock(corner4Block))
                cornerCount++;
            let center = Vector3Util.add(Vector3Util.add(location, side === 1 ? { x: 0, y: 1, z: 0 } : { x: 0, y: -3, z: 0 }), Vector3Util.add(Vector3Util.scale(negatedOffset, 0.5), {
                x: 0.5,
                y: 0,
                z: 0.5,
            }));
            validPortals.push({
                center: center,
                axis: offset.dir === Direction.North || offset.dir === Direction.South
                    ? "x"
                    : "z",
                isFull: cornerCount === 4,
                dimension: dimension.id,
                color: getColor(edge.color),
            });
        }
        if (validPortals.length > 0) {
            return validPortals;
        }
        return null;
    };
    Portal.findHorz = (dimension, location, side) => {
        let checkColumn; // we want to find the column adjacent to the clicked block using the clicked side
        switch (side) {
            case Direction.North:
                checkColumn = { x: location.x, y: location.y, z: location.z - 1 };
                break;
            case Direction.South:
                checkColumn = { x: location.x, y: location.y, z: location.z + 1 };
                break;
            case Direction.West:
                checkColumn = { x: location.x - 1, y: location.y, z: location.z };
                break;
            case Direction.East:
                checkColumn = { x: location.x + 1, y: location.y, z: location.z };
                break;
        }
        for (let i = 1; i <= 3; i++) {
            let block = dimension.getBlock(Vector3Util.add(checkColumn, { x: 0, y: i, z: 0 }));
            if (block.isValid() &&
                (block.isAir || Portal.isPortalFrameBlock(block))) {
                if (!block.isAir) {
                    // the block is a portal block so we can start searching using the vertical direction
                    return Portal.findVert(dimension, block.location, -1); // since we found a theoretical top block we need to search down
                }
            }
            else {
                // the block is not a portal block or empty so we can stop searching
                break;
            }
        }
        for (let i = 1; i <= 3; i++) {
            let block = dimension.getBlock(Vector3Util.add(checkColumn, { x: 0, y: -i, z: 0 }));
            if (block.isValid() &&
                (block.isAir || Portal.isPortalFrameBlock(block))) {
                if (!block.isAir) {
                    // the block is a portal block so we can start searching using the vertical direction
                    return Portal.findVert(dimension, block.location, 1); // since we found a theoretical top block we need to search down
                }
            }
            else {
                // the block is not a portal block or empty so we can stop searching
                break;
            }
        }
        return null;
    };
    Portal.find = (dimension, location, side) => {
        switch (side) {
            case Direction.Up:
            case Direction.Down:
                return Portal.findVert(dimension, location, side === Direction.Up ? 1 : -1);
            case Direction.North:
            case Direction.South:
            case Direction.West:
            case Direction.East:
                return Portal.findHorz(dimension, location, side);
        }
    };
    Portal.getId = (position) => {
        return `${position.center.x.toFixed(2)}:${position.center.y.toFixed(2)}:${position.center.z.toFixed(2)}:${position.axis}:${position.dimension}`;
    };
    Portal.create = (player, position) => {
        const uid = Portal.getId(position);
        const exists = Portal.store.has(uid);
        if (exists) {
            return;
        }
        system.run(() => {
            incrementStat(Stats.portals_placed);
            const color = position.color;
            Portal.discoveredStore.update(color, (v) => {
                if (!v)
                    incrementStat(Stats.unique_portals_placed);
                return true;
            });
            let existingPortals = Portal.store.entries().filter((v) => v[1].color === color);
            if (existingPortals.length >= 10) {
                // player.sendMessage(`§cYou can only have 10 portals of the same color`);
                player.onScreenDisplay.setActionBar({
                    "translate": "spark_portals.too_many_portals",
                    "with": {
                        "rawtext": [
                            { "translate": `spark_portals.color.${color}` },
                        ],
                    },
                });
                return;
            }
            const dim = world.getDimension(position.dimension);
            dim.runCommandAsync(`/playsound sound.spark_portals.portal_activate @a ${position.center.x} ${position.center.y} ${position.center.z}`);
            const marker = dim.spawnEntity("spark_portals:portal_marker", Vector3Util.add(position.center, Portal.portalEntityOffset));
            let data = {
                color,
                position: {
                    axis: position.axis,
                    center: position.center,
                    dimension: position.dimension,
                    isFull: position.isFull,
                },
                id: marker.id,
                name: null,
            };
            Portal.store.set(uid, data);
            // set name
            Ui.showPortalNameUi(player, (name) => {
                Portal.store.update(uid, (v) => {
                    v.name = name;
                    return v;
                });
            }, color);
            let portals = Portal.portalsByColor.get(color) || [];
            portals.push(uid);
            Portal.portalsByColor.set(color, portals);
            marker.setRotation({
                x: 0,
                y: position.axis === "x" ? 90 : 0,
            });
            if (position.isFull)
                marker.triggerEvent("spark_portals:portal_complete");
            marker.triggerEvent(`spark_portals:set_color_${color}`);
            // execute as @e[type=spark_portals:portal_marker] at @s run particle minecraft:basic_smoke_particle ~ ~ ~
            // marker.nameTag = uid;
            let unit = position.axis === "z" ? { x: -1, y: 0, z: 0 } : { x: 0, y: 0, z: -1 };
            let center = Vector3Util.add(position.center, position.axis === "z"
                ? { x: 0, y: 0, z: -0.5 }
                : { x: -0.5, y: 0, z: 0 });
            for (let x = 0; x < 2; x++) {
                for (let y = 0; y < 3; y++) {
                    let blockPos = Vector3Util.add(center, Vector3Util.add(Vector3Util.scale(unit, x), { x: 0, y: y, z: 0 }));
                    dim.runCommandAsync(`/setblock ${blockPos.x} ${blockPos.y} ${blockPos.z} spark_portals:portal_collision ["minecraft:cardinal_direction":"${position.axis === "x" ? "east" : "south"}"]`);
                }
            }
            if (position.isFull)
                makeFancy(data, dim);
            // let command = `execute rotated ${position.axis === "x" ? 90 : 0} 0 runfill ^-0.5 ^ ^ ^ ^2 ^0.5 spark_portals:portal_collision ["minecraft:cardinal_direction":"${position.axis === "x" ? "east" : "south"}"]`;
            // marker.runCommandAsync(command);
        });
    };
    function isBroken(dim, portal) {
        let portalPosition = portal.position;
        let unit = portalPosition.axis === "z"
            ? { x: -1, y: 0, z: 0 }
            : { x: 0, y: 0, z: -1 };
        let center = Vector3Util.add(portalPosition.center, portalPosition.axis === "z"
            ? { x: 0, y: 0, z: -0.5 }
            : { x: -0.5, y: 0, z: 0 });
        const isBorderBlock = createBlockTypeMatcher(`spark_portals:${portal.color}_portal_frame`);
        for (let x = 0; x < 2; x++) {
            for (let y = 0; y < 3; y++) {
                let blockPos = Vector3Util.add(center, Vector3Util.add(Vector3Util.scale(unit, x), { x: 0, y: y, z: 0 }));
                let block = dim.getBlock(blockPos);
                if (block &&
                    block.isValid() &&
                    !block.permutation.matches("spark_portals:portal_collision"))
                    return true;
            }
        }
        for (let x = 0; x < 2; x++) {
            for (let y = 0; y < 2; y++) {
                let ypos = y === 0 ? -1 : 3;
                let pos = Vector3Util.add(center, Vector3Util.add(Vector3Util.scale(unit, x), { x: 0, y: ypos, z: 0 }));
                let block = dim.getBlock(pos);
                // block.setPermutation(BlockPermutation.resolve("dirt"));
                if (block && !isBorderBlock(block))
                    return true;
            }
        }
        for (let y = 0; y < 3; y++) {
            for (let x = 0; x < 2; x++) {
                let xpos = x === 0 ? -1 : 2;
                let pos = Vector3Util.add(center, Vector3Util.add(Vector3Util.scale(unit, xpos), { x: 0, y: y, z: 0 }));
                let block = dim.getBlock(pos);
                // block.setPermutation(BlockPermutation.resolve("dirt"));
                if (block && !isBorderBlock(block))
                    return true;
            }
        }
        return false;
    }
    function makeFancy(portal, dim) {
        let { color, position } = portal;
        let axis = position.axis;
        let unit = axis === "z" ? { x: 1, y: 0, z: 0 } : { x: 0, y: 0, z: -1 };
        let center = Vector3Util.add(position.center, axis === "x" ? { x: 0, y: 0, z: -0.5 } : { x: 0.5, y: 0, z: 0 });
        let nearWallBottom = Vector3Util.add(center, Vector3Util.add(unit, { x: 0, y: -1, z: 0 }));
        let farWallBottom = Vector3Util.add(center, Vector3Util.add(Vector3Util.scale(unit, -2), { x: 0, y: -1, z: 0 }));
        let columnBlock = BlockPermutation.resolve(`spark_portals:${color}_portal_frame_column`);
        dim
            .getBlock(nearWallBottom)
            .setPermutation(BlockPermutation.resolve(`spark_portals:${color}_portal_bottom_corner_${axis}_alt`));
        dim
            .getBlock(farWallBottom)
            .setPermutation(BlockPermutation.resolve(`spark_portals:${color}_portal_bottom_corner_${axis}`));
        for (let i = 1; i <= 3; i++) {
            dim
                .getBlock(Vector3Util.add(nearWallBottom, { x: 0, y: i, z: 0 }))
                .setPermutation(columnBlock);
            dim
                .getBlock(Vector3Util.add(farWallBottom, { x: 0, y: i, z: 0 }))
                .setPermutation(columnBlock);
        }
        for (let i = 0; i <= 1; i++) {
            dim
                .getBlock(Vector3Util.add({ x: 0, y: -1, z: 0 }, Vector3Util.add(center, Vector3Util.scale(unit, -i))))
                .setPermutation(BlockPermutation.resolve(`spark_portals:${color}_portal_horizontal_${axis}`));
            dim
                .getBlock(Vector3Util.add({ x: 0, y: 3, z: 0 }, Vector3Util.add(center, Vector3Util.scale(unit, -i))))
                .setPermutation(BlockPermutation.resolve(`spark_portals:${color}_portal_horizontal_${axis}`));
        }
        dim
            .getBlock(Vector3Util.add(nearWallBottom, { x: 0, y: 4, z: 0 }))
            .setPermutation(BlockPermutation.resolve(`spark_portals:${color}_portal_top_corner_${axis}_alt`));
        dim
            .getBlock(Vector3Util.add(farWallBottom, { x: 0, y: 4, z: 0 }))
            .setPermutation(BlockPermutation.resolve(`spark_portals:${color}_portal_top_corner_${axis}`));
        // system.runTimeout(() => {
        // }, 10);
    }
    function makeNotFancy(portal, dim) {
        let { color, position } = portal;
        let blockPermutation = BlockPermutation.resolve(`spark_portals:${color}_portal_frame`);
        const matcher = createBlockTypeMatcher(color);
        function setBlock(pos) {
            let block = dim.getBlock(pos);
            if (block && block.isValid() && matcher(block)) {
                block.setPermutation(blockPermutation);
            }
        }
        let axis = position.axis === "x" ? "z" : "x";
        let unit = axis === "x" ? { x: -1, y: 0, z: 0 } : { x: 0, y: 0, z: -1 };
        let center = Vector3Util.add(position.center, axis === "z" ? { x: 0, y: 0, z: -0.5 } : { x: -0.5, y: 0, z: 0 });
        let nearWallBottom = Vector3Util.add(center, Vector3Util.add(unit, { x: 0, y: -1, z: 0 }));
        let farWallBottom = Vector3Util.add(center, Vector3Util.add(Vector3Util.scale(unit, -2), { x: 0, y: -1, z: 0 }));
        let columnBlock = BlockPermutation.resolve(`spark_portals:${color}_portal_frame_column`);
        setBlock(nearWallBottom);
        setBlock(farWallBottom);
        for (let i = 1; i <= 3; i++) {
            setBlock(Vector3Util.add(nearWallBottom, { x: 0, y: i, z: 0 }));
            setBlock(Vector3Util.add(farWallBottom, { x: 0, y: i, z: 0 }));
        }
        for (let i = 0; i <= 1; i++) {
            setBlock(Vector3Util.add({ x: 0, y: -1, z: 0 }, Vector3Util.add(center, Vector3Util.scale(unit, -i))));
            setBlock(Vector3Util.add({ x: 0, y: 3, z: 0 }, Vector3Util.add(center, Vector3Util.scale(unit, -i))));
        }
        setBlock(Vector3Util.add(nearWallBottom, { x: 0, y: 4, z: 0 }));
        setBlock(Vector3Util.add(farWallBottom, { x: 0, y: 4, z: 0 }));
    }
    function destroy(k, v, dim) {
        let markers = dim.getEntities({
            type: "spark_portals:portal_marker",
            location: Vector3Util.add(v.position.center, Portal.portalEntityOffset),
            maxDistance: 1,
        });
        incrementStat(Stats.portals_broken);
        dim.runCommandAsync(`/playsound sound.spark_portals.portal_deactivate @a ${v.position.center.x} ${v.position.center.y} ${v.position.center.z}`);
        let marker = markers.find((e) => e.id === v.id);
        if (!marker) {
            return;
        }
        let unit = v.position.axis === "z" ? { x: -1, y: 0, z: 0 } : { x: 0, y: 0, z: -1 };
        let center = Vector3Util.add(v.position.center, v.position.axis === "z"
            ? { x: 0, y: 0, z: -0.5 }
            : { x: -0.5, y: 0, z: 0 });
        let air = BlockPermutation.resolve("air");
        for (let x = 0; x < 2; x++) {
            for (let y = 0; y < 3; y++) {
                let blockPos = Vector3Util.add(center, Vector3Util.add(Vector3Util.scale(unit, x), { x: 0, y: y, z: 0 }));
                let block = dim.getBlock(blockPos);
                if (block &&
                    block.isValid() &&
                    block.permutation.matches("spark_portals:portal_collision"))
                    block.setPermutation(air);
            }
        }
        makeNotFancy(v, dim);
        Portal.store.delete(k);
        let portals = Portal.portalsByColor.get(v.color) || [];
        portals.splice(portals.indexOf(k), 1);
        Portal.portalsByColor.set(v.color, portals);
        marker.triggerEvent("spark_portals:despawn");
    }
    function teleportNonPlayerEntity(ent, pos, color) {
        const options = Portal.portalsByColor.get(color) || [];
        if (options.length <= 1)
            return;
        if (portalCooldown.hasParticipant(ent))
            return; // if the teleport cooldown has this entity, they are inadmissible for teleportation
        if (ent.typeId === "minecraft:fishing_hook") {
            let distance = Vector3Util.distance(ent.location, Vector3Util.add(pos.position.center, { x: 0, y: 1.5, z: 0 }));
            // if the fishing bobber is in the same place as the portal display kill it.
            if (distance < 0.004) {
                ent.kill();
                return;
            }
        }
        // entities have issues going between dimensions, so we only allow teleportation between portals in the same dimension
        const portals = options.map((id) => Portal.store.get(id)).filter((p) => ent.dimension.id.startsWith(p.position.dimension));
        if (portals.length <= 1)
            return; // there are no other portals in this dimension, so we can't teleport
        const sourceIdx = portals.findIndex((p) => p.id === pos.id);
        let rng = Math.floor(Math.random() * (portals.length - 1));
        if (rng >= sourceIdx)
            rng++;
        const portal = portals[rng];
        const rot = ent.getRotation();
        const thisPortalRot = pos.position.axis === "x" ? 90 : 0;
        const reverseRot = Math.abs(rot.y - thisPortalRot) > 90;
        const isOffAxis = pos.position.axis === portal.position.axis;
        const currentVelocity = ent.getVelocity();
        let newVelocity = currentVelocity;
        if (isOffAxis) {
            newVelocity = {
                x: currentVelocity.z,
                y: currentVelocity.y,
                z: currentVelocity.x,
            };
        }
        ent.applyImpulse(newVelocity);
        portalCooldown.setScore(ent, 20 * 30);
        ent.teleport(portal.position.center, {
            rotation: {
                x: rot.x,
                y: (isOffAxis ? 90 : 0) + (reverseRot ? 180 : 0),
            },
            dimension: world.getDimension(portal.position.dimension),
            keepVelocity: true,
            checkForBlocks: false
        });
        incrementStat(Stats.entities_times_teleported);
    }
    function teleportPlayer(ent, pos, color) {
        if (Ui.playersWithUiAction.has(ent.id) || lastPlayersInPortal.has(ent.id))
            return; // player is already being shown a ui, don't show another one
        if (portalCooldown.hasParticipant(ent))
            return; // if the teleport cooldown has this entity, they are inadmissible for teleportation
        let portals = Portal.portalsByColor.get(color) || [];
        if (portals.length === 0) {
            return;
        }
        Ui.showPortalTravelUi(ent, pos, portals.map((id) => Portal.store.get(id)), (portal) => {
            if (!Portal.store.hasValue(portal)) {
                ent.playSound('sound.spark_portals.tp_failed');
                return;
            }
            let sourceDim = world.getDimension(pos.position.dimension);
            let dim = world.getDimension(portal.position.dimension);
            sourceDim.spawnEntity("spark_portals:portal_loader", {
                x: pos.position.center.x,
                y: pos.position.center.y + 5,
                z: pos.position.center.z,
            });
            ent.teleport(portal.position.center, {
                dimension: dim,
            });
            incrementStat(Stats.times_teleported);
            portalCooldown.setScore(ent, 50);
        }, color);
    }
    function tickPortal(k, v, dim) {
        let internalEntities = dim.getEntities({
            location: v.position.center,
            maxDistance: 4,
            excludeFamilies: ["spark_portals"],
        });
        // the player can pull this entity with a fishing rod :( lets just put it back in the right spot every tick.
        let internalEntity = dim.getEntities({
            location: v.position.center,
            maxDistance: 4,
            families: ["spark_portals"],
        }).find(ent => ent.id === v.id);
        if (internalEntity) {
            internalEntity.teleport(Vector3Util.add(v.position.center, { x: 0, y: 1.5, z: 0 }), {
                rotation: internalEntity.getRotation()
            });
            internalEntity.clearVelocity();
        }
        if (internalEntities.length === 0)
            return;
        // warp entities
        let min = v.position.axis === "z"
            ? { x: -1, y: 0, z: -0.5 }
            : { x: -0.5, y: 0, z: -1 };
        let max = v.position.axis === "z" ? { x: 1, y: 3, z: 0.5 } : { x: 0.5, y: 3, z: 1 };
        for (const entity of internalEntities) {
            let location = entity.location;
            let offset = Vector3Util.subtract(location, v.position.center);
            if (offset.x >= min.x &&
                offset.x <= max.x &&
                offset.y >= min.y &&
                offset.y <= max.y &&
                offset.z >= min.z &&
                offset.z <= max.z) {
                // entity is inside the portal
                if (entity instanceof Player) {
                    if (Vector3Util.length(entity.getVelocity()) < 0.1) {
                        teleportPlayer(entity, v, v.color);
                        playersInPortal.set(entity.id, v.id);
                    }
                }
                else {
                    teleportNonPlayerEntity(entity, v, v.color);
                }
            }
        }
    }
    function findPortalsNear(dim, location, size) {
        let results = [];
        let portals = Portal.store.entries();
        for (const [k, v] of portals) {
            if (v.position.dimension === dim.id &&
                Math.sqrt(Math.pow(v.position.center.x - location.x, 2) +
                    Math.pow(v.position.center.y - location.y, 2) +
                    Math.pow(v.position.center.z - location.z, 2)) < size) {
                results.push([k, v]);
            }
        }
        return results;
    }
    function cornerBlocksUpdate(key, dim, portal, isAdd, force = false) {
        let isFullAlready = portal.position.isFull;
        if (isFullAlready === isAdd)
            return; // can't make a portal full if it is already full, or make it not full if it is already not full
        let unit = portal.position.axis === "z"
            ? { x: -1, y: 0, z: 0 }
            : { x: 0, y: 0, z: -1 };
        let center = Vector3Util.add(portal.position.center, portal.position.axis === "z"
            ? { x: 0, y: 0, z: -0.5 }
            : { x: -0.5, y: 0, z: 0 });
        let isBorderBlock = createBlockTypeMatcher(portal.color);
        // let isBorderBlock = (block: Block) => {
        // 	let res = temp(block);
        // 	// let originalPermutation = block.permutation;
        // 	// block.setPermutation(BlockPermutation.resolve("dirt"));
        // 	// system.runTimeout(() => {
        // 	// 	block.setPermutation(originalPermutation);
        // 	// }, 100);
        // 	return res;
        // }
        let count = 0;
        let BottomNearCornerLocation = Vector3Util.add(center, Vector3Util.add(Vector3Util.scale(unit, -1), { x: 0, y: -1, z: 0 }));
        let BottomFarCornerLocation = Vector3Util.add(center, Vector3Util.add(Vector3Util.scale(unit, 2), { x: 0, y: -1, z: 0 }));
        let TopNearCornerLocation = Vector3Util.add(center, Vector3Util.add(Vector3Util.scale(unit, -1), { x: 0, y: 3, z: 0 }));
        let TopFarCornerLocation = Vector3Util.add(center, Vector3Util.add(Vector3Util.scale(unit, 2), { x: 0, y: 3, z: 0 }));
        let BottomNearCornerBlock = dim.getBlock(BottomNearCornerLocation);
        if (isBorderBlock(BottomNearCornerBlock))
            count++;
        let BottomFarCornerBlock = dim.getBlock(BottomFarCornerLocation);
        if (isBorderBlock(BottomFarCornerBlock))
            count++;
        let TopNearCornerBlock = dim.getBlock(TopNearCornerLocation);
        if (isBorderBlock(TopNearCornerBlock))
            count++;
        let TopFarCornerBlock = dim.getBlock(TopFarCornerLocation);
        if (isBorderBlock(TopFarCornerBlock))
            count++;
        let isFull = count === 4;
        Portal.store.update(key, (v) => {
            v.position.isFull = isFull;
            return v;
        });
        if (isFullAlready !== isFull || force) {
            if (!force) {
                // update the portal marker
                let markers = dim.getEntities({
                    type: "spark_portals:portal_marker",
                    location: Vector3Util.add(portal.position.center, Portal.portalEntityOffset),
                    maxDistance: 1,
                });
                let marker = markers.find((e) => e.id === portal.id);
                if (!marker) {
                    return;
                }
                marker.triggerEvent(isFull
                    ? "spark_portals:portal_complete"
                    : "spark_portals:portal_incomplete");
                dim.runCommandAsync(`/playsound sound.spark_portals.portal_change @a ${portal.position.center.x} ${portal.position.center.y} ${portal.position.center.z}`);
            }
            if (isFull)
                makeFancy(portal, dim);
            else
                makeNotFancy(portal, dim);
        }
    }
    function rescan(location, dim, isAdd) {
        let portals = findPortalsNear(dim, location, 4);
        let portalIdsToRescan = new Set();
        for (const [id, portal] of portals) {
            if (isBroken(dim, portal)) {
                destroy(id, portal, dim);
                for (let [id2, portal2] of portals) {
                    if (portal2.position.dimension === portal.position.dimension && Vector3Util.distance(portal.position.center, portal2.position.center) < 10) {
                        portalIdsToRescan.add(id2);
                    }
                }
                portalIdsToRescan.delete(id);
            }
            else {
                cornerBlocksUpdate(id, dim, portal, isAdd);
            }
        }
        for (let id of portalIdsToRescan) {
            let portal = Portal.store.get(id);
            if (portal) {
                cornerBlocksUpdate(id, dim, portal, null, true);
            }
        }
    }
    Portal.rescan = rescan;
    Portal.isLocationNearPortal = (location, dim) => {
        let portals = findPortalsNear(dim, location, 10);
        return portals.length > 0;
    };
    Portal.tick = () => {
        // NOTE: this can be slowed down if needed later on by only processing a few portals per tick.
        for (const [k, v] of Portal.store.entries()) {
            const dim = world.getDimension(v.position.dimension);
            const centerBlock = dim.getBlock(Vector3Util.floor(v.position.center));
            if (centerBlock && centerBlock.isValid()) {
                // it is most likely loaded
                tickPortal(k, v, dim);
            }
        }
        for (let id of lastPlayersInPortal.keys()) {
            if (!playersInPortal.has(id)) {
                // player is no longer in portal
                Ui.resetUi(id);
            }
            else if (lastPlayersInPortal.has(id) && playersInPortal.get(id) !== lastPlayersInPortal.get(id)) {
                // the player is in a different portal
                // this should really not happen since the ui should not allow an open for a player that was already in a ui action but its not a bad edge case to have
                Ui.resetUi(id);
            }
        }
        lastPlayersInPortal = playersInPortal;
        playersInPortal = new Map();
        for (const x of portalCooldown.getParticipants()) {
            try {
                // this is a bit of a hack but x.getEntity() will throw an error if the entity is not loaded.
                // so in this manner we can only count down the cooldown for entities that are loaded
                x.getEntity();
                const score = portalCooldown.getScore(x);
                if (score > 0) {
                    portalCooldown.addScore(x, -1);
                }
                else {
                    portalCooldown.removeParticipant(x);
                }
            }
            catch (e) { }
        }
    };
})(Portal || (Portal = {}));
//# sourceMappingURL=portal.js.map