import { ScoreboardIdentityType, system } from "@minecraft/server";
import { getOrCreateScoreboard } from "./util/getOrCreateScoreboard";
export class PersistantStore {
    id;
    data = new Map();
    scoreboard;
    prefix = "";
    hasSaveQueued = false;
    constructor(id) {
        this.id = id;
        this.scoreboard = getOrCreateScoreboard(id);
        this.prefix = id + ";";
        let data = [];
        for (const participant of this.scoreboard.getParticipants()) {
            if (participant.type === ScoreboardIdentityType.FakePlayer && participant.displayName.startsWith(this.prefix)) {
                let dataBit = participant.displayName.slice(this.prefix.length);
                let value = this.scoreboard.getScore(participant);
                // rebuild the data array in order if for some reason its out of order
                data[value - 1] = dataBit;
            }
        }
        if (data.length === 0) {
            this.data = new Map();
        }
        else {
            this.data = new Map(JSON.parse(data.join("")));
        }
    }
    resetScoreboard() {
        for (const participant of this.scoreboard.getParticipants()) {
            this.scoreboard.removeParticipant(participant);
        }
    }
    save() {
        if (!this.hasSaveQueued) {
            this.hasSaveQueued = true;
            system.run(() => {
                this.hasSaveQueued = false;
                let chunkSize = 1024;
                let dataSize = chunkSize - this.prefix.length;
                let data = JSON.stringify([...this.data.entries()]);
                this.resetScoreboard();
                let chunkCount = 0;
                for (let i = 0; i < data.length; i += dataSize) {
                    chunkCount++;
                    this.scoreboard.setScore(this.prefix + data.slice(i, i + dataSize), chunkCount);
                }
                this.scoreboard.setScore(`${data.length} (${chunkCount})`, 0);
            });
        }
    }
    get(key) {
        return this.data.get(key);
    }
    set(key, value) {
        this.data.set(key, value);
        this.save();
    }
    update(key, updater) {
        this.set(key, updater(this.get(key)));
    }
    delete(key) {
        let res = this.data.delete(key);
        if (res)
            this.save();
        return res;
    }
    has(key) {
        return this.data.has(key);
    }
    hasValue(value) {
        return Array.from(this.data.values()).includes(value);
    }
    entries() {
        return Array.from(this.data.entries());
    }
}
//# sourceMappingURL=store.js.map