import { world } from "@minecraft/server";
const statsScoreboardName = "spark_portals:jig_computer.addon_stats";
const scoreboard = world.scoreboard.getObjective(statsScoreboardName) ?? world.scoreboard.addObjective(statsScoreboardName, "Portals Addons Stats");
export var Stats;
(function (Stats) {
    Stats["portals_placed"] = "portals_placed";
    Stats["portals_broken"] = "portals_broken";
    Stats["times_teleported"] = "times_teleported";
    Stats["entities_times_teleported"] = "entities_times_teleported";
    Stats["unique_portals_placed"] = "unique_portals_placed";
})(Stats || (Stats = {}));
;
//  = "portals_placed" | "portals_broken" | "times_teleported" | "entities_times_teleported" | "unique_portals_placed";
export function incrementStat(stat) {
    scoreboard.setScore(`spark_portals:${stat}`, (scoreboard.hasParticipant(`spark_portals:${stat}`) ? scoreboard.getScore(`spark_portals:${stat}`) : 0) + 1);
}
//# sourceMappingURL=stats.js.map